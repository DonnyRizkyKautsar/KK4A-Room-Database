package com.example.roomdatabase.Adapter;

public class UserAdapter {
}
